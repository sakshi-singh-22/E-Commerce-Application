// Initialize OlaMaps SDK
const olaMaps = new OlaMapsSDK.OlaMaps({
    apiKey: 'qroEyHXjE5gw3beENGUi167RyZnu0IBh9T5KW9a4', // Replace with your actual API key
});

// Call the init method to render the map
const myMap = olaMaps.init({
    style: "https://api.olamaps.io/tiles/vector/v1/styles/default-light-standard/style.json",
    container: 'map',
    center: [77.61648476788898, 12.931423492103944], // Initial position
    zoom: 15, // Zoom level
});

// Function to add static markers on the map (for users, drivers, etc.)
function addStaticMarkers() {
    const locations = [
        { name: 'User 1', coordinates: [77.616, 12.935] },
        { name: 'Driver 1', coordinates: [77.618, 12.934] },
        { name: 'Vendor 1', coordinates: [77.620, 12.932] },
    ];

    locations.forEach(location => {
        const marker = new OlaMapsSDK.Marker({
            position: location.coordinates,
            title: location.name,
        });

        marker.addTo(myMap);
    });
}

// Adding static markers for testing
addStaticMarkers();
